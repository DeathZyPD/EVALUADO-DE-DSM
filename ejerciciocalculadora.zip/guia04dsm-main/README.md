Guía #05- Recursos

<img src="https://github.com/AlexanderSiguenza/guia04dsm/blob/main/img/calculadora.png" alt="Ejemplo de calculadora, practica de Recursos" width="300" height="600">
